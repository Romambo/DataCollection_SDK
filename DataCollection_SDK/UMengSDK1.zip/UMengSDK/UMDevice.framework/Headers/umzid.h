//
//  UMZid.h
//  UMZid
//
//  Created by Li CL on 2020/5/27.
//  Copyright © 2020 umeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UMZid : NSObject

+ (NSString *)getZData;

+ (NSString *)getZVersion;


@end
