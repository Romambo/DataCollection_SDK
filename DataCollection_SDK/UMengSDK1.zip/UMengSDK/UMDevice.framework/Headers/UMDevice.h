//
//  UMDevice.h
//  UMDevice
//
//  Created by Li CL on 2020/5/28.
//  Copyright © 2020 umeng. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for UMDevice.
FOUNDATION_EXPORT double UMDeviceVersionNumber;

//! Project version string for UMDevice.
FOUNDATION_EXPORT const unsigned char UMDeviceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UMDevice/PublicHeader.h>
#import <UMDevice/umzid.h>

